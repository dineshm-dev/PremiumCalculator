import { validateVerticalPosition } from '@angular/cdk/overlay';
import { Component, OnInit } from '@angular/core';
import { AbstractControl, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Messages } from './Common/CommonMessages';
import { CustomvalidationService } from './Common/Validators/CustomValidators';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  
  title = 'Calculate Premium';
  premiumCalcForm: FormGroup;
  addEditUserValidationMessages : any;
  occupationList:any;
  model2:any;

  constructor(private _fb: FormBuilder, private customValidator: CustomvalidationService){}

  ngOnInit(): void {
     this.createForm();
     
     this.occupationList = [ { value : "1", displayText:"Cleaner" },  { value : "2", displayText:"Doctor" },  
     { value : "3", displayText:"Author" },     { value : "4", displayText:"Farmer" },
     { value : "5", displayText:"Mechanic" }];

     this.addEditUserValidationMessages = {
      name: {
        required: Messages.requiredMsg('Name'),
      },
      age: {
        required: Messages.requiredMsg('Age'),
        maxlength : Messages.maxlengthForHtmlEditorMsgs('Age', 2),
        invalidNumber: Messages.invalidMsg("Age")
      },
      
    };

    this.premiumCalcForm.valueChanges
			.subscribe(() => this.onValueChanged());
  }

  createForm() {
		this.premiumCalcForm = this._fb.group({
			
			name: ['', Validators.required],
			age: ['', [Validators.required, this.customValidator.numericvalidator.bind(this.customValidator),
      Validators.maxLength(2),]
    ],
    occupations:[null, [Validators.required]],
   // occupation:[0, Validators.required],
    birthDate:['',Validators.required],
    insuredamount:['',Validators.required]
		});

		
  }
  formErrors = {
		name: '',
		age:'',
    occupations:'',
    //occupation:'',
    birthDate:'',
    insuredamount:''
	};

  
  calculatePremium(){
    console.log(this.premiumCalcForm.value)
  }

  onValueChanged() {
		if (!this.premiumCalcForm) { return; }
		const form = this.premiumCalcForm;
		// tslint:disable-next-line:forin
		for (const field in this.formErrors) {
			const control = form.get(field);
			this.formErrors[field] = '';
			if (control && control.dirty && !control.valid) {
				const messages = this.addEditUserValidationMessages[field];

				
					for (const key in control.errors) {
						if (key !== null || key !== undefined) {
							this.formErrors[field] += messages[key] + ' ';
						}
					}
				
			}
		}
	}

  OnPageSelected(value){
    this.premiumCalcForm.controls.occupations.setValue(value);
  }
}



