import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { MatFormFieldModule, MatInputModule, MatSelectModule } from '@angular/material';
import { ReactiveFormTestComponent } from './Presentation/reactive-form-test/reactive-form-test.component';
import { CustomvalidationService } from './Common/Validators/CustomValidators';
import { PremiumformComponent } from './Presentation/premiumform/premiumform.component';

@NgModule({
  declarations: [
    AppComponent,
    ReactiveFormTestComponent,
    PremiumformComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    BrowserAnimationsModule,
    MatFormFieldModule,
    MatInputModule,
    MatSelectModule,
    
  ],
  providers: [CustomvalidationService],
  bootstrap: [AppComponent]
})
export class AppModule { }
