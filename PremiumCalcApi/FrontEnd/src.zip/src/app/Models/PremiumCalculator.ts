export class PremiumCalculator{
    public  Name : string;

    public  OccupationId : number

    public  Age : number

    public  DateOfBirth : Date

    public  DeathSumInsured : number

}