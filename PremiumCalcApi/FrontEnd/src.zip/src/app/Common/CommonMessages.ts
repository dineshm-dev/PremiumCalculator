export const Messages = {
    maxlengthForHtmlEditorMsgs: (param1, param2) => param1 + ' cannot be more than ' + param2 + ' characters.',
    requiredMsg: params => 'Please enter ' + params + '.',
    invalidMsg: params => params + ' is invalid.',
    
};