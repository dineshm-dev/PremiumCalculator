import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import * as internal from 'assert';
import { CustomvalidationService } from 'src/app/Common/Validators/CustomValidators';
import { PremiumCalculator } from 'src/app/Models/PremiumCalculator';

@Component({
  selector: 'app-premiumform',
  templateUrl: './premiumform.component.html',
  styleUrls: ['./premiumform.component.css']
})
export class PremiumformComponent implements OnInit {
  
  title = 'Calculate Premium';
  premiumCalcForm: FormGroup;
  addEditUserValidationMessages : any;
  occupationList:any;
  model2:any;
  submitted = false;
  occupationId: number;
  calculatedamount : number = 0;

  constructor(private _fb: FormBuilder, private customValidator: CustomvalidationService){}

  ngOnInit() {
    this.occupationList = [ { value : "1", displayText:"Cleaner" },  { value : "2", displayText:"Doctor" },  
    { value : "3", displayText:"Author" },     { value : "4", displayText:"Farmer" },
    { value : "5", displayText:"Mechanic" }];
     this.createForm();
  }

  createForm() {
		this.premiumCalcForm = this._fb.group({
			
			name: ['', Validators.required],
			age: ['', [Validators.required, this.customValidator.numericvalidator.bind(this.customValidator),
      Validators.maxLength(2),]
    ],
    occupations:[null, [Validators.required]],
    occupationId:[],
   // occupation:[0, Validators.required],
    dateofbirth:['',Validators.required],
    deathsumInsured:['',Validators.required]
		});
		
  }
  get premiumFormControl() {
    return this.premiumCalcForm.controls;
  }

  onSubmit() {
    this.submitted = true;


    if (this.premiumCalcForm.valid) {
      
      console.log(this.premiumCalcForm.getRawValue());
      
      this.calculatedamount = 500;
      return false;
    }

  }

  OnOccupationSelected(value){
    this.premiumCalcForm.controls.occupationId.setValue(value);
    if(this.premiumCalcForm.valid && value != "-1"){
      console.log(value);
      this.onSubmit();
    }
  }
}
